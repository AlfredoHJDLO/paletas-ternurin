// src/components/ProductGrid.jsx
import React from 'react';
import ProductCard from './ProductCard';
import mockProducts from '../data/mockProducts';

function ProductGrid() {
  const handleAddToCart = (productId) => {
    console.log(`Paleta con ID ${productId} agregada al carrito.`);
  };

  return (
    <section id="productos" style={{
      padding: '40px 0', // Elimina el padding horizontal del section si quieres que ocupe todo el ancho visualmente
      backgroundColor: '#333', // O el color de fondo de tu imagen (negro/gris oscuro)
      color: 'white' // Para que el texto sea visible sobre fondo oscuro
    }}>
      <h2 style={{
        fontSize: '36px',
        color: '#c4978c', // Puedes ajustar el color si el fondo es oscuro
        textAlign: 'center',
        marginBottom: '40px'
      }}>
        Nuestros Productos
      </h2>
      {/* Contenedor interno para centrar el grid de productos */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'center',
        gap: '20px',
        maxWidth: '1200px', // Aquí mantenemos el ancho máximo para centrar el contenido
        margin: '0 auto', // Centra el contenedor de las tarjetas
        padding: '0 20px' // Añade padding a los lados dentro del contenedor centrado
      }}>
        {mockProducts.map((product) => (
          <ProductCard
            key={product.id}
            imageSrc={product.image}
            name={product.name}
            price={product.price}
            hasOffer={product.hasOffer}
            offerText={product.offerText}
            onAddToCart={() => handleAddToCart(product.id)}
          />
        ))}
      </div>
    </section>
  );
}

export default ProductGrid;