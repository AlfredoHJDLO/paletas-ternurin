import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import ProductGrid from './components/ProductGrid';
import Footer from './components/Footer';

function App() {
  return (
    <div style={{
      fontFamily: 'Arial, sans-serif',
      margin: 0,
      padding: 0,
      //boxSizing: 'border-box'
    }}>
      <Header />
      <HeroSection />
      {/* El título "Nuestros Productos" ya está dentro de ProductGrid,
          pero si quieres un título aparte, podrías ponerlo aquí:
          <h2 style={{ textAlign: 'center', marginTop: '50px', fontSize: '36px', color: '#c4978c' }}>Nuestros Productos</h2>
      */}
      <ProductGrid />
      <Footer />
    </div>
  );
}

export default App;